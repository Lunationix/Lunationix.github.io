# Migrations

Data (user data, config files etc.) is migrated from one version to another.

Migrations are called by {} from {} during {}.