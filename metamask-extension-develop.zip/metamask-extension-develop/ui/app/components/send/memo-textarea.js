// const Component = require('react').Component
// const h = require('react-hyperscript')
// const inherits = require('util').inherits
// const Identicon = require('../identicon')

// module.exports = MemoTextArea

// inherits(MemoTextArea, Component)
// function MemoTextArea () {
//   Component.call(this)
// }

// MemoTextArea.prototype.render = function () {
//   const { memo, identities, onChange } = this.props

//   return h('div.send-v2__memo-text-area', [

//     h('textarea.send-v2__memo-text-area__input', {
//       placeholder: 'Optional',
//       value: memo,
//       onChange,
//       // onBlur: () => {
//       //   this.setErrorsFor('memo')
//       // },
//       onFocus: event => {
//         // this.clearErrorsFor('memo')
//       },
//     }),

//   ])

// }

