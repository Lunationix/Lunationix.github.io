const LoadingScreen = require('./loading-screen.component')
module.exports = LoadingScreen
