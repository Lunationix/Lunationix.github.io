const Spinner = require('./spinner.component')
module.exports = Spinner
