global.metamask = require('metamascara')
