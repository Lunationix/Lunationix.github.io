# Development Tools & Configurations

This folder contains configuration files which are used by the the different
development-tools, like e.g. JsDoc.


## Appveyor


https://www.appveyor.com/docs/build-configuration/#alternative-yaml-file-location

Withtin the configuration, point to a weblocation of a txt config file:

https://ci.appveyor.com/project/lazaridiscom/mm-vault/settings
https://raw.githubusercontent.com/lazaridiscom/mm-vault/master/dev/tools/appveyor.txt
